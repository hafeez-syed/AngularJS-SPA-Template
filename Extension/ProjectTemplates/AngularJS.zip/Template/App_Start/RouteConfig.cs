// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RouteConfig.cs" company="KriaSoft LLC">
//   Copyright � 2013 Konstantin Tarkus, KriaSoft LLC. See LICENSE.txt
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace App.$safeprojectname$
{
    using System.Web.Routing;

    using App.$safeprojectname$.Routing;

    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Add("Default", new DefaultRoute());
        }
    }
}
